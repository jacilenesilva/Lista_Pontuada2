/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

unsigned long long fatorial(int num) {
    unsigned long long fat = 1;
    for (int i = 1; i <= num; i++) {
        fat *= i;
    }
    return fat;
}


int somatorio(int num) {
    return (num * (num + 1)) / 2;  
}

int main() {
    int n, m;

    printf("Quantos valores deseja ler? ");
    scanf("%d", &n);

    printf("\nValor\tSomatório\tFatorial\n");
    printf("-------------------------------\n");

    for (int i = 1; i <= n; i++) {
        do {
            printf("Digite o %dº valor: ", i);
            scanf("%d", &m);
            if (m <= 0) {
                printf("Apenas números positivos.\n");
            }
        } while (m <= 0);

        printf("%d\t%d\t\t%llu\n", m, somatorio(m), fatorial(m));
    }

    return 0;
}
