/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int ehPrimo(int num) {
    if (num < 2) return 0;
    for (int i = 2; i <= sqrt(num); i++) {
        if (num % i == 0) return 0;
    }
    return 1;
}

int main() {
    unsigned long long produto = 1;
    int contador = 0;

    for (int i = 92; i <= 1478; i++) {
        if (ehPrimo(i)) {
            produto *= i;
            contador++;

            
            printf("Primo %3d: %d\n", contador, i);
        }
    }

    printf("\nQuantidade de primos encontrados: %d\n", contador);
    printf("Produto parcial: %llu\n", produto);//vai ser exibido apenas uma parte do resultado para não ultrapassar o armazenamento

    return 0;
}

