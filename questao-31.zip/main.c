/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int i, valor;
    int dentroIntervalo = 0, foraIntervalo = 0;

    printf("Digite 10 valores inteiros:\n");

    for (i = 1; i <= 10; i++) {
        printf("Valor %d: ", i);
        scanf("%d", &valor);

        if (valor >= 10 && valor <= 20) {
            dentroIntervalo++;
        } else {
            foraIntervalo++;
        }
    }

    printf("\nQuantidade de valores no intervalo [10,20]: %d\n", dentroIntervalo);
    printf("Quantidade de valores fora do intervalo: %d\n", foraIntervalo);

    return 0;
}
