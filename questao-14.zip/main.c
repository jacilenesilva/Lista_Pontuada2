/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int valor, soma = 0, contador = 0, positivos = 0, negativos = 0;
     float media, percentualPositivos, percentualNegativos;

   

    while (1) {
        printf("Valor %d: ", contador + 1);
        scanf("%d", &valor);

        if (valor == 0) {
            break; 
        }

        soma += valor;
        contador++;

        if (valor > 0) {
            positivos++;
        } else if (valor < 0) {
            negativos++;
        }
    }

    if (contador == 0) {
        printf("Nenhum valor foi inserido.\n");
    } else {
         media = (float)soma / contador;
         percentualPositivos = ((float)positivos / contador) * 100;
         percentualNegativos = ((float)negativos / contador) * 100;

      
        printf("Quantidade de valores lidos: %d\n", contador);
        printf("Média aritmética: %.2f\n", media);
        printf("Quantidade de positivos: %d\n", positivos);
        printf("Quantidade de negativos: %d\n", negativos);
        printf("Percentual de positivos: %.2f%%\n", percentualPositivos);
        printf("Percentual de negativos: %.2f%%\n", percentualNegativos);
    }

    return 0;
}
