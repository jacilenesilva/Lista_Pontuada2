/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int a, negativos = 0;

    for (int i = 1; i <= 5; i++) {
        printf("Digite o %dº valor: ", i);
        scanf("%d", &a);

        if (a < 0) {
            negativos++;
        }
    }

    printf("Quantidade de valores negativos: %d\n", negativos);

    return 0;
}
