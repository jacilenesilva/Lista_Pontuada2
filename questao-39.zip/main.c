/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int numero = 2;     
    int contador = 0;    

    printf("Os 5 primeiros números perfeitos são:\n");

    while (contador < 5) {
        int soma = 0;

        // soma dos divisores próprios
        for (int i = 1; i <= numero / 2; i++) {
            if (numero % i == 0) {
                soma += i;
            }
        }

        if (soma == numero) {
            printf("%d\n", numero);
            contador++;
        }

        numero++;
    }

    return 0;
}
