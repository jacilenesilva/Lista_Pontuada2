/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int i, soma = 0, contador = 0;
    float media;

    for (i = 13; i <= 73; i++) {
        soma += i;
        contador++;
    }

    media = (float)soma / contador;

    printf("Média aritmética dos números entre 13 e 73: %.2f\n", media);

    return 0;
}
