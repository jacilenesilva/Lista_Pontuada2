/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int codigo;
    float precoCusto, precoNovo;
    int contador = 0;
    float somaPrecoCusto = 0, somaPrecoNovo = 0;

    printf("Digite o código e o preço de custo do produto (código negativo para encerrar):\n");

    while (1) {
        printf("\nCódigo do produto: ");
        scanf("%d", &codigo);

        if (codigo < 0) {
            break; 
        }

        printf("Preço de custo: R$ ");
        scanf("%f", &precoCusto);

        precoNovo = precoCusto * 1.20; 

        printf("Código: %d - Preço com aumento: R$ %.2f\n", codigo, precoNovo);

        somaPrecoCusto += precoCusto;
        somaPrecoNovo += precoNovo;
        contador++;
    }

    if (contador > 0) {
        printf("\nMédia dos preços de custo: R$ %.2f\n", somaPrecoCusto / contador);
        printf("Média dos preços com aumento: R$ %.2f\n", somaPrecoNovo / contador);
    } else {
        printf("\nNenhum produto foi registrado.\n");
    }

    return 0;
}

