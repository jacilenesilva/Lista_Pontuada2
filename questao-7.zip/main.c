/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int codigo;
    float nota1, nota2, nota3, media;

    printf("Digite o código do aluno: ");
    scanf("%d", &codigo);

    while (codigo != 0) {
        printf("Digite as 3 notas do aluno %d:\n", codigo);
        scanf("%f %f %f", &nota1, &nota2, &nota3);

    
        media = (nota1 + nota2 + nota3) / 3;

        printf("A média do aluno %d é: %.2f\n\n", codigo, media);

        printf("Digite o código do próximo aluno: ");
        scanf("%d", &codigo);
    }

    
    return 0;
}
