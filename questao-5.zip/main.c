/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int valor, soma = 0, contador = 0;
    float media;

    printf("Digite valores inteiros positivos (valor negativo para encerrar):\n");

    while (1) {
        scanf("%d", &valor);

        if (valor < 0) {
            break; 
        }

        soma += valor;
        contador++;
    }

    if (contador > 0) {
        media = (float)soma / contador;
        printf("Média aritmética: %.2f\n", media);
    } else {
        printf("Nenhum valor positivo foi informado.\n");
    }

    return 0;
}
