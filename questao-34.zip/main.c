/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int numeroAluno, maisAltoNumero = 0, maisBaixoNumero = 0;
    int altura, maiorAltura = 0, menorAltura = 1000; 

    for (int i = 1; i <= 5; i++) {
        printf("\nConjunto %d:\n", i);
        printf("Número do aluno: ");
        scanf("%d", &numeroAluno);

        printf("Altura em cm: ");
        scanf("%d", &altura);

        if (altura > maiorAltura) {
            maiorAltura = altura;
            maisAltoNumero = numeroAluno;
        }

        if (altura < menorAltura) {
            menorAltura = altura;
            maisBaixoNumero = numeroAluno;
        }
    }


    printf("Aluno mais alto: Nº %d com altura %d cm\n", maisAltoNumero, maiorAltura);
    printf("Aluno mais baixo: Nº %d com altura %d cm\n", maisBaixoNumero, menorAltura);

    return 0;
}

