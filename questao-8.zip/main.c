/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int numero, soma = 0, contador = 0;
    float media;

    printf("Informe um numero:\n");

    do {
        printf("Digite um número: ");
        scanf("%d", &numero);

        if (numero != 0 && numero % 2 == 0) {
            soma += numero;
            contador++;
        }

    } while (numero != 0);

    if (contador > 0) {
        media = (float)soma / contador;
        printf("A média é: %.2f\n", media);
    } else {
        printf("Digite numeros pares.\n");
    }

    return 0;
}

