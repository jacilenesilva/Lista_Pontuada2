/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

int main() {
    char sexo;
    char corOlhos[10];
    char corCabelos[10];
    int idade;

    printf("Digite os dados dos habitantes:\n");

    while (1) {
        printf("\nIdade: ");
        scanf("%d", &idade);
        if (idade < 0) {
            break;
        }

        printf("Sexo (M/F): ");
        scanf(" %c", &sexo);

        printf("Cor dos olhos (azuis, verdes ou castanhos): ");
        scanf("%s", corOlhos);

        printf("Cor dos cabelos (louros, castanhos ou pretos): ");
        scanf("%s", corCabelos);

      
        printf("Idade: %d\n", idade);
        printf("Sexo: %c\n", sexo);
        printf("Cor dos olhos: %s\n", corOlhos);
        printf("Cor dos cabelos: %s\n", corCabelos);
    }

   
    return 0;
}

