/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
     int N, i, j;
    double E = 0.0;
    
    printf("Digite um valor inteiro e positivo para N: ");
    scanf("%d", &N);

    for (i = 0; i <= N; i++) {
        int fatorial = 1;
        for (j = 1; j <= i; j++) {
            fatorial *= j;
        }
        E += 1.0 / fatorial;
        
        printf ("%.2f \n", E);
    }

    printf("O valor de E é: %.2f\n", E);

    return 0;
}
