/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int numero, somaNegativos = 0;

    printf("Digite números inteiros (0 para encerrar):\n");

    while (1) {
        printf("Número: ");
        scanf("%d", &numero);

        if (numero == 0) {
            break; 
        }

        if (numero < 0) {
            somaNegativos += numero;
        }
    }

    printf("\nSomatório dos números negativos: %d\n", somaNegativos);

    return 0;
}
