/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int codigo;
    float nota1, nota2, nota3, maior, media;;
    

    do {
        printf("\nDigite o código do aluno : ");
        scanf("%d", &codigo);

        if (codigo < 0) {
            break;
        }

        printf("Digite a primeira nota: ");
        scanf("%f", &nota1);

        printf("Digite a segunda nota: ");
        scanf("%f", &nota2);

        printf("Digite a terceira nota: ");
        scanf("%f", &nota3);

        
        if (nota1 >= nota2 && nota1 >= nota3) {
            maior = nota1;
            media = (nota1 * 4 + nota2 * 3 + nota3 * 3 - maior * 3) / 10;
        } else if (nota2 >= nota1 && nota2 >= nota3) {
            maior = nota2;
            media = (nota2 * 4 + nota1 * 3 + nota3 * 3 - maior * 3) / 10;
        } else {
            maior = nota3;
            media = (nota3 * 4 + nota1 * 3 + nota2 * 3 - maior * 3) / 10;
        }

        
        printf("Aluno: %d\n", codigo);
        printf("Notas: %.1f, %.1f, %.1f\n", nota1, nota2, nota3);
        printf("Média final: %.2f\n", media);

        if (media >= 5.0) {
            printf("APROVADO\n");
        } else {
            printf("REPROVADO\n");
        }

    } while (codigo >= 0);

    

    return 0;
}
