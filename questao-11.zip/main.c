/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int n, a1, razao, termo, soma = 0;;
     

    printf("Digite o número de termo: ");
    scanf("%d", &n);

    printf("Digite o primeiro termo: ");
    scanf("%d", &a1);

    printf("Digite a razão da PA : ");
    scanf("%d", &razao);

    printf("Os %d termos da progressão aritmética são:", n);

    for (int i = 0; i < n; i++) {
        termo = a1 + i * razao;
        printf("%d ", termo);
        soma += termo;
    }

    printf("\n Soma dos termos: %d\n", soma);

    return 0;
}

