/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

unsigned long long fatorial(int num) {
    unsigned long long fat = 1;
    for (int i = 1; i <= num; i++) {
        fat *= i;
    }
    return fat;
}

int main() {
    int N, valor;

    printf("Quantos valores você deseja ler? ");
    scanf("%d", &N);

    printf("\nValor\tFatorial\n");
    printf("---------------\n");

    for (int i = 1; i <= N; i++) {
        printf("Digite o %dº valor: ", i);
        scanf("%d", &valor);

        if (valor < 0) {
            printf("Fatorial não definido para valores negativos.\n");
        } else {
            printf("%d\t%llu\n", valor, fatorial(valor));
        }
    }

    return 0;
}
