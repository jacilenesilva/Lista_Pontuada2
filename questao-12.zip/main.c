/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int n;

    for (int i = 1; i <= 20; i++) {
        printf("\nDigite o %dº valor para n: ", i);
        scanf("%d", &n);

        printf("Tabuada de 1 até %d:\n", n);
        for (int j = 1; j <= n; j++) {
            printf("%d x %d = %d\n", j, n, j * n);
        }
    }

    
    return 0;
}
