/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main() {
    double X;

    printf("Digite o valor de X: ");
    scanf("%lf", &X);

    if (X == 0) {
        printf("Não é possível dividir por zero!\n");
        return 1;
    }

    printf("\n20 primeiros termos da série:\n");
    for (int i = 1; i <= 20; i++) {
        double termo = 1.0 / pow(X, i);
        printf("1 / %.0f^%d = %.10f\n", X, i, termo);
    }

    return 0;
}
