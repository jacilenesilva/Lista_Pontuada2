/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int m, n, i, soma;

    printf("Digite pares de valores m e n \n");

    while (1) {
        printf("\nDigite m: ");
        scanf("%d", &m);

        printf("Digite n: ");
        scanf("%d", &n);

        if (m <= 0 || n <= 0) {
            break; 
        }

        soma = 0;
        for (i = 0; i < n; i++) {
            soma += m + i;
        }

        printf("Soma dos %d números a partir de %d: %d\n", n, m, soma);
    }

    return 0;
}
