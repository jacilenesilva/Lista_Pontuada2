/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int i, numero, maior = 0, menor = 0;
    long long soma = 0;  
    float media;

    printf("Digite 500 números inteiros e positivos:\n");

    for (i = 1; i <= 5; i++) {
        do {
            printf("Número %d: ", i);
            scanf("%d", &numero);
            if (numero <= 0) {
                printf("Por favor, digite um número inteiro e positivo.\n");
            }
        } while (numero <= 0);

        soma += numero;

        if (i == 1) {
            maior = numero;
            menor = numero;
        } else {
            if (numero > maior) {
                maior = numero;
            }
            if (numero < menor) {
                menor = numero;
            }
        }
    }

    media = (float)soma / 5;

 
    printf("Maior valor: %d\n", maior);
    printf("Menor valor: %d\n", menor);
    printf("Média dos números: %.2f\n", media);

    return 0;
}
