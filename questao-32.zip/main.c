/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int a, b;

    for (int i = 1; i <= 5; i++) {
        
        do {
            printf("\nPar %d:\n", i);
            printf("Digite o valor de a: ");
            scanf("%d", &a);
            printf("Digite o valor de b: ");
            scanf("%d", &b);

            if (a <= 0 || b <= 0 || a >= b) {
                printf("Entrada inválida!\n");
            }
        } while (a <= 0 || b <= 0 || a >= b);

        printf("Números pares entre %d e %d:\n", a, b);
        for (int j = a; j <= b; j++) {
            if (j % 2 == 0) {
                printf("%d ", j);
            }
        }
        printf("\n");
    }

    return 0;
}

