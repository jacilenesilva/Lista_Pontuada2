/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

int main() {
    int idade;
    char sexo;
    char corOlhos[15];
    char corCabelos[15];

    int maiorIdade = 0;
    int contadorMulheres = 0;

    printf("Digite os dados dos habitantes:\n");

    while (1) {
        printf("\nIdade: ");
        scanf("%d", &idade);
        if (idade == -1) {
            break;
        }

        printf("Sexo (M/F): ");
        scanf(" %c", &sexo);

        printf("Cor dos olhos (azuis, verdes ou castanhos): ");
        scanf("%s", corOlhos);

        printf("Cor dos cabelos (louros, castanhos ou pretos): ");
        scanf("%s", corCabelos);

        if (idade > maiorIdade) {
            maiorIdade = idade;
        }

        if ((sexo == 'F' || sexo == 'f') && idade >= 18 && idade <= 35 &&
            (strcmp(corOlhos, "verdes") == 0) &&
            (strcmp(corCabelos, "louros") == 0)) {
            contadorMulheres++;
        }
    }

    printf("Maior idade dos habitantes: %d\n", maiorIdade);
    printf("Quantidade de mulheres entre 18 e 35 anos, com olhos verdes e cabelos louros: %d\n", contadorMulheres);

    return 0;
}
