/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

unsigned long long fatorial(int num) {
    unsigned long long fat = 1;
    for (int i = 1; i <= num; i++) {
        fat *= i;
    }
    return fat;
}

int main() {
    int n, valor;

    printf("Quantos valores deseja ler? ");
    scanf("%d", &n);

    printf("\n%-10s | %-20s\n", "Valor", "Fatorial");
    printf("-------------------------------\n");

    for (int i = 1; i <= n; i++) {
        printf("Digite o %dº valor: ", i);
        scanf("%d", &valor);

        if (valor < 0) {
            printf("%-10d | Fatorial não definido para negativos\n", valor);
        } else {
            printf("%-10d | %-20llu\n", valor, fatorial(valor));
        }
    }

    return 0;
}
