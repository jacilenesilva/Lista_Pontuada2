/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    float altura, maiorAltura = 0.0, menorAltura = 1000.0;
    float somaAlturas = 0.0, somaAlturasMulheres = 0.0, mediaTurma, mediaMulheres;
    int sexo, qtdMulheres = 0;

    for (int i = 1; i <= 5; i++) {
        printf("\nPessoa %d\n", i);


        do {
            printf("Digite a altura : ");
            scanf("%f", &altura);
            if (altura <= 0) {
                printf("Informe uma altura válida.\n");
            }
        } while (altura <= 0);

        do {
            printf("Digite o sexo (1 = masculino, 2 = feminino): ");
            scanf("%d", &sexo);
            if (sexo != 1 && sexo != 2) {
                printf("Tente novamente.\n");
            }
        } while (sexo != 1 && sexo != 2);

        somaAlturas += altura;

        
        if (altura > maiorAltura) {
            maiorAltura = altura;
        }
        if (altura < menorAltura) {
            menorAltura = altura;
        }

        if (sexo == 2) {
            somaAlturasMulheres += altura;
            qtdMulheres++;
        }
    }

    
     mediaTurma = somaAlturas / 5;
   mediaMulheres = (qtdMulheres > 0) ? (somaAlturasMulheres / qtdMulheres) : 0;

  
    printf(" Maior altura: %.2f m\n", maiorAltura);
    printf(" Menor altura: %.2f m\n", menorAltura);
    printf(" Média da altura das mulheres: %.2f m\n", mediaMulheres);
    printf("Média da altura da turma: %.2f m\n", mediaTurma);

    return 0;
}
