/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int idade, qtdPessoas = 0, maiorIdade = 0, menorIdade = 150, mulheresSalarioBaixo = 0;
    char sexo;
    float salario, somaSalarios = 0;
     

     
 

    printf("Digite os dados dos habitantes:\n");

    while (1) {
        printf("\nIdade: ");
        scanf("%d", &idade);

        if (idade < 0) {
            break;
        }

        if (idade > maiorIdade) {
            maiorIdade = idade;
        }
        if (idade < menorIdade) {
            menorIdade = idade;
        }

        printf("Sexo (M/F): ");
        scanf(" %c", &sexo); 

        printf("Salário: R$ ");
        scanf("%f", &salario);

      
        somaSalarios += salario;
        qtdPessoas++;

        if ((sexo == 'F' || sexo == 'f') && salario <= 100.00) {
            mulheresSalarioBaixo++;
        }
    }

    if (qtdPessoas == 0) {
        printf("\nNenhum dado foi inserido.\n");
    } else {
        float mediaSalario = somaSalarios / qtdPessoas;

        
        printf("Média salarial do grupo: R$ %.2f\n", mediaSalario);
        printf(" Maior idade: %d anos\n", maiorIdade);
        printf(" Menor idade: %d anos\n", menorIdade);
        printf(" Mulheres com salário até R$100,00: %d\n", mulheresSalarioBaixo);
    }

    return 0;
}
