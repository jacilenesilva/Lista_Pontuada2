/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

void imprimirCabecalho() {
    printf("\n%-10s %-10s %-10s %-15s\n", "Valor", "Quadrado", "Cubo", "Raiz Quadrada");
    printf("----------------------------------------------------------\n");
}

int main() {
    float valor;
    int contadorLinhas = 0;

    printf("Digite valores (número negativo para encerrar):\n");

    while (1) {
        printf("Valor: ");
        scanf("%f", &valor);

        if (valor < 0) {
            break;
        }

        if (contadorLinhas % 20 == 0) {
            imprimirCabecalho();
        }

        printf("%-10.2f %-10.2f %-10.2f %-15.4f\n",
               valor,
               pow(valor, 2),
               pow(valor, 3),
               sqrt(valor));

        contadorLinhas++;
    }

    return 0;
}

