/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int numero;
    unsigned long long produtorio = 1;
    int Par = 0; 

    printf("Digite números inteiros positivos:\n");

    while (1) {
        printf("Número: ");
        scanf("%d", &numero);

        if (numero == 0) {
            break; 
        }

        if (numero < 0) {
            printf("Somente positivos ou 0.\n");
            continue;
        }

        if (numero % 2 == 0) {
            produtorio *= numero;
            Par = 1;
        }
    }

    if (Par) {
        printf("\nProdutório dos números pares: %llu\n", produtorio);
    } else {
        printf("\nNenhum número par foi digitado.\n");
    }

    return 0;
}
