/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    float chico = 1.50, ze = 1.10;
    int contador = 0;

    while (ze <= chico) {
        chico += 0.02; // Chico cresce 2 cm por ano
        ze += 0.03;    // Zé cresce 3 cm por ano
        contador++;
    }

    printf("Serão necessários %d anos para que Zé seja mais alto que Chico.\n", contador);
    printf("Altura final de Zé: %.2f m\n", ze);
    printf("Altura final de Chico: %.2f m\n", chico);

    return 0;
}
