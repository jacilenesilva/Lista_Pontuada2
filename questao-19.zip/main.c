/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int numero, somaPares = 0, somaTotal = 0;
    int qtdPares = 0, qtdImpares = 0, totalNumeros = 0;
     

    printf("Digite números positivos:\n");

    while (1) {
        printf("Número: ");
        scanf("%d", &numero);

        if (numero == 0) {
            break;
        }

        if (numero > 0) {
            totalNumeros++;
            somaTotal += numero;

            if (numero % 2 == 0) {
                qtdPares++;
                somaPares += numero;
            } else {
                qtdImpares++;
            }
        } else {
            printf("Apenas positivos ou zero.\n");
        }
    }

    if (totalNumeros == 0) {
        printf("\nNenhum número válido foi lido.\n");
    } else {
        float mediaPares = qtdPares > 0 ? (float)somaPares / qtdPares : 0;
        float mediaGeral = (float)somaTotal / totalNumeros;

       
        printf("Quantidade de pares: %d\n", qtdPares);
        printf("Quantidade de ímpares: %d\n", qtdImpares);
        printf("Média dos pares: %.2f\n", mediaPares);
        printf("Média geral: %.2f\n", mediaGeral);
    }

    return 0;
}
